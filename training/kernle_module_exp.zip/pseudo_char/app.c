#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>


#define DEVICE "/dev/pseudo_char"

int main()
{

	int fd;
	char write_buf[100], read_buf[100];

	fd = open(DEVICE, O_RDWR);

	if(fd < 0)
		perror("unable to open the device ");
	else
		printf("File opened successfully %d\n",fd);

	printf("Writing ... \n");
	write(fd, write_buf, sizeof(write_buf));
	
	printf("Reading ... \n");
	read(fd, read_buf, sizeof(read_buf));
	printf("read_buf : %s\n", read_buf);


	return 0;

}
